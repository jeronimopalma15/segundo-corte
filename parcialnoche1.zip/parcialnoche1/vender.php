<?php
require 'config/conex.php';
    $tipo= $_POST["tipo"];
    $cantidad = $_POST["cantidad"];
    $descuento = 0;


if($tipo==1)
{
    $valor=300; 
    $subtotal= $valor * $cantidad; 
    }

if($tipo==2)
{
    $valor=400;  
    $subtotal= $valor * $cantidad;
    }
    
if($tipo==3)
    {
        $valor=500;  
        $subtotal= $valor * $cantidad;    
        }
    
    if( $cantidad <= 20 ){
        $descuento = 0;
    }

    if ($cantidad >= 21 && $cantidad <= 40) {
        $descuento = $subtotal * 0.05; 
    } 

    if ($cantidad >= 41) {
        $descuento = $subtotal * 0.1; 
    }
    $total = $subtotal - $descuento;

    $sql = "INSERT INTO huevos(tipo,cantidad,valor) VALUES (".$tipo.",".$cantidad.",".$total.")";

   if($dbh ->query($sql))
{
    //aparecera este mensaje
    echo "venta registrada"; 
}
 else
 {
    //error aparece esto
    echo "error en la venta";
 }

 

    echo "<p>Subtotal: $" . $subtotal . "</p>";
    echo "<p>Descuento: $" . $descuento . "</p>";
    echo "<p>Total: $" . $total . "</p>";

?>