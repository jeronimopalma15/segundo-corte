<?php

require "config/conex.php";

$id = $_POST["id"];
$gasto = $_POST["gasto"];


$sql="UPDATE clientes
 SET
 saldo=saldo-".$gasto."
  WHERE 
 id=".$id."";

if($dbh-> query($sql))
{
    echo"Gasto correctamente guardado";
}
else {
    echo "erro de gasto";
}
?>