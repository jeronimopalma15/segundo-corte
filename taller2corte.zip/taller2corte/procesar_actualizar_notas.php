<?php

require "config/conex.php";

$id = $_POST["id"];
$nota1 = $_POST["nota1"];
$nota2 = $_POST["nota2"];
$nota3 = $_POST["nota3"];
$total = ($nota1* 0.3) + ($nota2 * 0.3) + ($nota3 * 0.4);

$sql="UPDATE notas
 SET
 nota1=".$nota1.",
 nota2=".$nota2.",
 nota3=".$nota3.",
 total=".$total."
 WHERE 
 id=".$id."";

if($dbh-> query($sql))
{
    echo"Nota Actualizada correctamente";
}
else {
    echo "No se pudo Realizar la modificación";
}
?>
