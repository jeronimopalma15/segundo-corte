<?php

require "config/conex.php";

$nombre = $_POST["nombre"];
$nota1 = $_POST["nota1"];
$nota2 = $_POST["nota2"];
$nota3 = $_POST["nota3"];
$total = ($nota1* 0.3) + ($nota2 * 0.3) + ($nota3 * 0.4);


$sql= "INSERT INTO notas(nombre,nota1,nota2,nota3,total) 
VALUES ('".$nombre."',".$nota1.",".$nota2.",".$nota3.",".$total.")";

if($dbh->query($sql)) {

    echo "SU NOTA ES $total <br>";

        if ($total < 3.0) {
        echo " PERDIÓ la materia.";
    } else {
        echo "PASO la materia.";
    }
} else {
    echo "Error de nota";
}
?>

